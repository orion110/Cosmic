#!/usr/bin/env python3
import os, sys, gi
gi.require_version("Gtk", "4.0")
gi.require_version("WebKit", "6.0")
from gi.repository import Gtk, Gio, GLib, GObject, WebKit

APP_ID = "io.github.cosmic.Cosmic"
INDEX = "/app/share/cosmic/index.html"
if not os.path.exists(INDEX):  # running outside flatpak
    INDEX = os.path.join(os.path.dirname(os.path.abspath(__file__)), "index.html")

class App(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID)

    def do_activate(self):
        win = self.props.active_window
        if win:
            return win.present()
        win = Gtk.ApplicationWindow(application=self, title="Cosmic",
                                    default_width=1280, default_height=800)
        # Persistent storage so localStorage/IndexedDB survive restarts
        data = os.path.join(GLib.get_user_data_dir(), "webkit")
        cache = os.path.join(GLib.get_user_cache_dir(), "webkit")
        session = WebKit.NetworkSession.new(data, cache)
        session.connect("download-started", self.on_download)
        view = GObject.new(WebKit.WebView, network_session=session)
        s = view.get_settings()
        for p in ("allow-file-access-from-file-urls", "allow-universal-access-from-file-urls",
                  "enable-developer-extras"):
            try: s.set_property(p, True)
            except TypeError: pass
        view.connect("decide-policy", self.on_policy)
        view.connect("permission-request", lambda v, r: r.allow() or True)
        view.load_uri(Gio.File.new_for_path(INDEX).get_uri())
        win.set_child(view)
        win.present()

    def on_policy(self, view, decision, dtype):
        # Open external links in the system browser
        if dtype in (WebKit.PolicyDecisionType.NAVIGATION_ACTION,
                     WebKit.PolicyDecisionType.NEW_WINDOW_ACTION):
            uri = decision.get_navigation_action().get_request().get_uri()
            if uri.startswith(("http://", "https://")) and not uri.startswith(
                    ("http://localhost", "http://127.0.0.1")):
                Gio.AppInfo.launch_default_for_uri(uri, None)
                decision.ignore()
                return True
        return False

    def on_download(self, session, download):
        def decide(dl, name):
            d = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD) or GLib.get_home_dir()
            base, ext = os.path.splitext(name or "download")
            path, i = os.path.join(d, base + ext), 1
            while os.path.exists(path):
                path = os.path.join(d, f"{base} ({i}){ext}"); i += 1
            dl.set_destination(path)
            return True
        download.connect("decide-destination", decide)

if __name__ == "__main__":
    sys.exit(App().run(sys.argv))
